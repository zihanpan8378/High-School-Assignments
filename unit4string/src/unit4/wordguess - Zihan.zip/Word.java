/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit4;

/**
 *
 * @author 44869
 */
public class Word {
    String Word, Guess, Final;
    int Letters;

    public String getWord() {
        return Word;
    }

    public void setWord(String Word) {
        this.Word = "player";
    }

    public String getGuess() {
        return Guess;
    }

    public void setGuess(String Guess) {
        this.Guess = Guess;
    }

    public String getFinal() {
        return Final;
    }

    public void setFinal(String Final) {
        this.Final = Final;
    }
     
    
    
}
