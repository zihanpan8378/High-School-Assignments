/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unit4;

/**
 *
 * @author 44869
 */
public class testFormative_2 {
    public static void main(String[] args) {
        Formative_2 f = new Formative_2();
        f.setNum();
        f.getAverage();
        System.out.println("The maximum number entered is: " + f.getMaximum());
        f.getRange();
        System.out.println("The minimum number entered is: " + f.getMinimum());
        
        
    }    
}
