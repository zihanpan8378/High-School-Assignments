/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuItem;

/**
 *
 * @author 44869
 */
public interface MenuItem {

    /**
     * @return the name of the menu item
     */
    String getName();

    /**
     * @return the price of the menu item
     */
    double getPrice();

}
