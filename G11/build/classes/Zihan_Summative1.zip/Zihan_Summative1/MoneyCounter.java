/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zihan_Summative1;

/**
 *
 * @author 44869
 */
public class MoneyCounter {
    double amount;
    public double getAmount(){
        return amount;
    }

}
