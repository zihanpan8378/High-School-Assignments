/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GradebookApp;

/**
 *
 * @author 44869
 */
public class Student {

    String firstName, lastName;
    double mathGrade, literatureGrade, scienceGrade, historyGrade;

    Student(String f, String ln, double m, double lg, double s, double h){
        firstName = f;
        lastName = ln;
        mathGrade = m;
        literatureGrade = lg;
        scienceGrade = s;
        historyGrade = h;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getMathGrade() {
        return mathGrade;
    }

    public void setMathGrade(double mathGrade) {
        this.mathGrade = mathGrade;
    }

    public double getLiteratureGrade() {
        return literatureGrade;
    }

    public void setLiteratureGrade(double literatureGrade) {
        this.literatureGrade = literatureGrade;
    }

    public double getScienceGrade() {
        return scienceGrade;
    }

    public void setScienceGrade(double scienceGrade) {
        this.scienceGrade = scienceGrade;
    }

    public double getHistoryGrade() {
        return historyGrade;
    }

    public void setHistoryGrade(double historyGrade) {
        this.historyGrade = historyGrade;
    }

    public double getAverage() {
        double total;
        total = getMathGrade() + getLiteratureGrade() + getScienceGrade() + getHistoryGrade();
        return total / 4;
    }

    public String getLetterGrade() {
        String letter;
        if (getAverage() >= 85) {
            letter = "A*";
        } else if (getAverage() >= 80) {
            letter = "A";
        } else if (getAverage() >= 70) {
            letter = "B";
        } else if (getAverage() >= 60) {
            letter = "C";
        } else if (getAverage() >= 50) {
            letter = "D";
        } else {
            letter = "F";
        }
        return letter;
    }

    @Override
    public String toString() {
        return getFirstName() + " " + getLastName() + " "
                + getMathGrade() + " " + getLiteratureGrade() + " "
                + getScienceGrade() + " " + getHistoryGrade() + " "
                + getAverage() + " " + getLetterGrade();
    }

}
