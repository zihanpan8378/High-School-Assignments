/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GradebookApp;

/**
 *
 * @author 44869
 */
public class Gradebook {

    Student[] s;
    int count = 0;

    Gradebook() {
        s = new Student[10];
    }

    public void add(Student student) {
        if (count < s.length) {
            s[count] = student;
            count++;
        } else {

        }
    }

    public void remove(String fn, String ln, Student[] student) {
        int i;
        for (i = 0; i < student.length; i++) {
            if (student[i].getFirstName().equals(fn)
                    && student[i].getLastName().equals(ln)) {
                break;
            }
        }
        if (i == (student.length - 1)) {
            System.out.println("There isn't this student.");
        } else {
            for (int j = i; j < student.length - 1; j++) {
                student[j] = student[j + 1];
            }
            student[student.length - 1] = null;
            if (count != 0) {
                count--;
            }
        }
    }

    public void print(Student[] student) {
        for (int i = 0; i < student.length; i++) {
            if (student[i] != null) {
                System.out.println(student[i]);
            }
        }
    }

    public void printOne(Student student) {
        int i;
        for (i = 0; i < s.length; i++) {
            if (s[i].getFirstName().equals(student.getFirstName())
                    && s[i].getLastName().equals(student.getLastName())) {
                break;
            }
        }
        if (i == (s.length - 1)) {
            System.out.println("There isn't this student.");
        } else {
            System.out.println(s[i]);
        }
    }

    public void printHighest() {

        double highest = 0;
        for (int i = 0; i < s.length; i++) {
            if (s[i] != null) {
                if (s[i].getAverage() > highest) {
                    highest = s[i].getAverage();
                } else {

                }
            }
        }
        for (int i = 0; i < s.length; i++) {
            if (s[i] != null) {
                if (s[i].getAverage() == highest) {
                    printOne(s[i]);
                }
            }
        }
    }

    public void printLowest() {
        double lowest = 100;
        for (int i = 0; i < s.length; i++) {
            if (s[i] != null) {
                if (s[i].getAverage() < lowest) {
                    lowest = s[i].getAverage();
                } else {

                }
            }
        }
        for (int i = 0; i < s.length; i++) {
            if (s[i] != null) {
                if (s[i].getAverage() == lowest) {
                    printOne(s[i]);
                }
            }
        }
    }

    public Student[] fail() {
        int c = 0;
        for (int i = 0; i < s.length; i++) {
            if (s[i] != null) {
                if (s[i].getAverage() < 50) {
                    c++;
                }
            }
        }
        Student[] f = new Student[c + 1];
        c = 0;
        for (int i = 0; i < s.length; i++) {
            if (s[i] != null) {
                if (s[i].getAverage() < 50) {
                    f[c] = s[i];
                    c++;
                }
            }
        }
        return f;
    }

    public Student[] top3() {
        Student[] t3 = new Student[3];
        Student[] m = s;
        for (int i = 0; i < t3.length; i++) {
            double highest = 0;
            int count2 = 0;
            for (int j = 0; j < m.length; j++) {
                if (m[j] != null) {
                    if (m[j].getAverage() > highest) {
                        highest = m[j].getAverage();
                        count2 = j;
                    }
                }
            }
            t3[i] = m[count2];
            remove(m[count2].getFirstName(), m[count2].getLastName(), m);
        }
        return t3;
    }
    
}
