/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ticket;

import java.util.Scanner;

/**
 *
 * @author 44869
 */
public class Purchase extends Buyer {

    int age, days;
    int count;
    StudentEarlyPurchase[] t;

    public Purchase(String fN, String lN, String address, double postalFee, int length) {
        super(fN, lN, address, postalFee);
        t = new StudentEarlyPurchase[length];
    }

    public void add(StudentEarlyPurchase a) {

        if (count < this.t.length) {
            this.t[count] = a;
            count++;
        } else {
            System.out.println("Out of range");
        }
    }

    public double totalPrice(StudentEarlyPurchase[] p) {
        double total = 0;
        for (int i = 0; i < p.length; i++) {
            if (p[i] != null) {
                total += p[i].getDiscount();
            }
        }
        return total + super.getPostalFee();
    }

    public void remove(int num) {
        for (int i = 0; i < t.length; i++) {
            if (t[i] != null && t[i].getTicketNumber() == num) {
                for (int j = i; j < t.length - 1; j++) {
                    t[j] = t[j + 1];
                    t[j + 1] = null;
                }
                i--;
            }
        }
    }

    public void print(StudentEarlyPurchase[] p) {
        for (int i = 0; i < p.length; i++) {
            if (p[i] != null) {
                System.out.println(p[i] + "\n");
            }
        }
    }

    public void printOne(int num) {
        for (int i = 0; i < t.length; i++) {
            if (t[i] != null && t[i].getTicketNumber() == num) {
                System.out.println(t[i]);
            }
        }
    }

    @Override
    public String toString() {
        return super.toString();
    }
    
    
}

class testPurchase {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Purchase p = new Purchase("Zihan", "Pan", "JIS", 3.0, 6);
        System.out.println(p + "\n\n");
        p.add(new StudentEarlyPurchase(001, 5, 10, true));
        p.add(new StudentEarlyPurchase(002, 7, 5, true));
        p.add(new StudentEarlyPurchase(003, 4, 6, false));
        p.add(new StudentEarlyPurchase(003, 8, 8, true));
        p.add(new StudentEarlyPurchase(004, 10, 3, false));
        p.add(new StudentEarlyPurchase(005, 15, 15, true));
        p.print(p.t);
        System.out.println("");
        p.remove(003);
        p.print(p.t);
        System.out.println("");
        p.remove(001);
        p.print(p.t);
        System.out.println("");
        p.printOne(005);
        System.out.println(p.totalPrice(p.t));
    }
}
/*extends = is-a
implements = is-a*/
