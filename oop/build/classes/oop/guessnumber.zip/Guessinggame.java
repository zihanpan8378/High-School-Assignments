/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop;

import java.util.Scanner;

/**
 *
 * @author 44869
 */
public class Guessinggame {

    public static void main(String[] args) {
        //declare object scanner and random and variables
        Scanner in = new Scanner(System.in);
        int n = 0;
        Compval c = new Compval();
        c.setNum();

        String answer = "";

        do {
            System.out.print("Enter your guess: ");
            n = in.nextInt();
            

            if (n == c.getNum()) {
                System.out.println("You are right.");
                System.out.println("Do you want to guess again?");
                answer = in.next();
            }
            if ((n != c.getNum())) {

                System.out.println("You are wrong.");
                System.out.println("Do you want to guess again?");
                answer = in.next();
            }
        } while (answer.equals("yes"));

    }
}
